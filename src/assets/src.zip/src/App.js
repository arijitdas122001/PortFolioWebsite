import "./App.css";
import Tableui from "./components/Tableui";
function App() {
  return (
    <div className="App">
      <Tableui/>
    </div>
  );
}

export default App;
