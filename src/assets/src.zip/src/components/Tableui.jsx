import React from "react";
import { DataGrid } from "@mui/x-data-grid";

const columns = [
  { field: "id", headerName: "Sl No", width: 70, align: "left", headerAlign: "left" },
  { field: "CustomerOrderID", headerName: "Customer Order ID", width: 150, align: "left", headerAlign: "left" },
  { field: "SalesOrg", headerName: "SalesOrg", type: "number", width: 130, align: "left", headerAlign: "left" },
  {
    field: "DistributionChannel",
    headerName: "Distribution Channel",
    width: 290,
    align: "left", 
    headerAlign: "left",
  },
  {
    field: "ComapanyCode",
    headerName: "Comapany Code",
    type: "number",
    width: 120,
    align: "left", 
    headerAlign: "left",
  },
  {
    field: "OrderCreationDate",
    headerName: "Order Creation Date",
    width: 160,
    align: "left", 
    headerAlign: "left",
  },
  {
    field: "OrderAmount",
    headerName: "Order Amount",
    type: "number",
    width: 160,
    align: "left", 
    headerAlign: "left",
  },
  {
    field: "OrderCurrency",
    headerName: "Order Currency",
    width: 160,
    align: "left", 
    headerAlign: "left",
  },
  {
    field: "CustomerNumber",
    headerName: "Customer Number",
    type: "number",
    width: 160,
    align: "left", 
    headerAlign: "left",
  },
];

const rows = [
  { id: 1, CustomerOrderID: "754349803", SalesOrg: 3911, DistributionChannel: "United Arab Emirates", ComapanyCode: 3290, OrderCreationDate: "01-01-2022", OrderAmount: 1405.54, OrderCurrency: "AED", CustomerNumber: 1210499770 },
  { id: 2, CustomerOrderID: "930253442", SalesOrg: 2381, DistributionChannel: "Greece", ComapanyCode: 3290, OrderCreationDate: "01-01-2022", OrderAmount: 1441.4835, OrderCurrency: "EUR", CustomerNumber: 1210351400 },
  { id: 3, CustomerOrderID: "819741436", SalesOrg: 3605, DistributionChannel: "Argentina", ComapanyCode: 3290, OrderCreationDate: "01-01-2022", OrderAmount: 1065.33, OrderCurrency: "EUR", CustomerNumber: 1210124309 },
  { id: 4, CustomerOrderID: "881355361", SalesOrg: 3645, DistributionChannel: "Armenia", ComapanyCode: 3470, OrderCreationDate: "01-01-2022", OrderAmount: 302.85, OrderCurrency: "EUR", CustomerNumber: 12311152 },
  { id: 5, CustomerOrderID: "821659852", SalesOrg: 2470, DistributionChannel: "United States of America", ComapanyCode: 3220, OrderCreationDate: "01-01-2022", OrderAmount: 8380.69, OrderCurrency: "EUR", CustomerNumber: 1230021722 },
  { id: 6, CustomerOrderID: "957194828", SalesOrg: 3150, DistributionChannel: "United States Minor Outlying Islands", ComapanyCode: 3290, OrderCreationDate: "01-01-2022", OrderAmount: 545.85, OrderCurrency: "EUR", CustomerNumber: 1210183107 },
  { id: 7, CustomerOrderID: "806322513", SalesOrg: 3396, DistributionChannel: "Serbia", ComapanyCode: 3290, OrderCreationDate: "01-01-2022", OrderAmount: 545.85, OrderCurrency: "EUR", CustomerNumber: 1210499770 },
  { id: 8, CustomerOrderID: "922237131", SalesOrg: 2353, DistributionChannel: "Turks and Caicos Islands", ComapanyCode: 3290, OrderCreationDate: "01-01-2022", OrderAmount: 562.73, OrderCurrency: "EUR", CustomerNumber: 1210111951 },
];

const Table = () => {
  return (
    <div style={{ height: "100vh", width: "100%", display: "flex", justifyContent: "center", alignItems: "center", background: "#666666" }}>
      <div>
        <DataGrid
          style={{ background: "#666666", color: "white", border: "10px solid #FC7500" }}
          rows={rows}
          columns={columns}
          checkboxSelection
        />
      </div>
    </div>
  );
};

export default Table;
